/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imageona4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import javax.swing.JOptionPane;

/**
 *
 * @author VIVEK
 */
public class IsSecurityPass {
    
    public void IsSecurityPass(){
    
    }
    public String getMacAddress(){
        String error="error";
        // a variable of type InetAddress to store the
        // address of the local host
        
        try{
        InetAddress addr = InetAddress.getLocalHost();
        NetworkInterface iface = NetworkInterface.getByInetAddress(addr);
         byte[] mac = iface.getHardwareAddress();
        // convert the obtained byte array into a printable
        // String
        String[] hexadecimal = new String[mac.length];
                for (int i = 0; i < mac.length; i++) {
            hexadecimal[i] = String.format("%02x", mac[i]);
        }
        String macAddress = String.join("x", hexadecimal);
        return macAddress;
        }catch(Exception ex)
        {
          
          return error;
        }
        
    }
    public char[] reverseString(String str){
           char[] f1=str.toCharArray();
           int l,r=0;
           r=f1.length -1;
           for(l=0;l<r;l++,r--)
           {
            char temp=f1[l];
            f1[l]=f1[r];
            f1[r]=temp;
           }
           return f1;
    }
    public String myHash(String str){
            String first="",second="";
            int len=str.length();
            first=str.substring(0,len/2);
            second=str.substring(len/2,len);
           char[] f1=reverseString(first);
           char[] f2=reverseString(second);
            len=first.length();
           String result="";
           for(int i=0;i<len;i=i+3)
           {
             result = result+f1[i]+f2[i];
           }
          // System.out.println(str+" my hash #"+result);
           return result;
    }
    public String getMd5(String input)
    {
        String hashtext="None";
        try {
  
            // Static getInstance method is called with hashing MD5
            MessageDigest md = MessageDigest.getInstance("MD5");
  
            // digest() method is called to calculate message digest
            //  of an input digest() return array of byte
            byte[] messageDigest = md.digest(input.getBytes());
  
            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);
  
            // Convert message digest into hex value
             hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }

            return hashtext;
        } 
  
        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            return hashtext; 
        }
    }
    public int isSecurityCodeTrue(){
        
         int i=0;
         String data[]={""};
         try {

            File f = new File("security.txt");

            BufferedReader b = new BufferedReader(new FileReader(f));
            String readLine = "";
            while ((readLine = b.readLine()) != null) {
                     if(i==0)
                     { data[i]=readLine; 
                       break;  // read only first line and break
                     }
                     
            }
        } catch (IOException e) {
            //JOptionPane.showMessageDialog(this, "Run as administrator and then enter activation code!","Error",JOptionPane.ERROR);
           return 2;
        }
        
        String str="666"+getMacAddress()+"999";
        String myhash=myHash(getMd5(str));
        if(myhash.equals(data[0]))
        {
          return 1;
        }
        else
          return 0;
    }
    public int setSecurityCode(String code,ActivationWindow window)
    {
      // Content to be assigned to a file
        // Custom input just for illustratinon purposes
        String text=code;
        // Try block to check if exception occurs
        try {
 
            // Create a FileWriter object
            // to write in the file
            FileWriter fWriter = new FileWriter("security.txt");
 
            // Writing into file
            // Note: The content taken above inside the
            // string
            fWriter.write(text);
 
            fWriter.close();
 
           
        }
        catch (IOException e) {
            JOptionPane.showMessageDialog(window, "Run as administrator and then enter activation code!","Warning!",JOptionPane.WARNING_MESSAGE);      
            return 0;
        }
        int k=isSecurityCodeTrue();
        if( k == 1)
        {
            JOptionPane.showMessageDialog(window, "Congratulations! \n Activation code accepted!","Activation Success!",JOptionPane.INFORMATION_MESSAGE);      
            return 1;
        }
        else if(k == 0)
        {
            JOptionPane.showMessageDialog(window, "Wrong Activation Code! \n\n Contact : gate2021.vivek@gmail.com","Activation Failed!",JOptionPane.ERROR_MESSAGE);      
            return 0;
        }
        else
            JOptionPane.showMessageDialog(window, "Some files are missing! \n Reinstall Software","Error!",JOptionPane.ERROR);      
            return 0;
    
    }
}
