/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imageona4;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import javax.swing.Icon;
import javax.swing.JOptionPane;


/**
 *
 * @author VIVEK
 */
public class ResizeImage {
 
          
    public boolean isImageRatioAcceptable(String file){
    

           Image image = null;
            try{
            image = Image.getInstance(file);
            }catch(Exception ex){
            
            }
        float i=  image.getWidth();
        float j=  image.getHeight();
        float ratio = (float)i/j;
        System.out.println(i+"  "+j+" "+ratio);
         
        if(ratio <= 0.6f)
            return false;
        
        return true;
           
    }
}
