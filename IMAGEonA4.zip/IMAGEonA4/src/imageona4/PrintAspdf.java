/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imageona4;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfDocument;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;

/**
 *
 * @author VIVEK
 */
public class PrintAspdf extends Thread {
    
    String dest;
    Document document;
    ArrayList<String> selectedFiles;
    float dpi,dpcm;
    JButton start;
    float imgWidth,imgHeight;
    int selectedColumn;
    float top_Margin;
    public PrintAspdf(String dest,ArrayList<String> selectedFiles,JButton start,float width,float height,int selectedColumn,float topMargin){
        
        this.dest = dest;
        this.selectedFiles =selectedFiles;
        this.start =start;
        this.imgWidth = width;
        this.imgHeight = height;
        dpi=java.awt.Toolkit.getDefaultToolkit().getScreenResolution(); 
        dpcm = dpi / 2.54f; // 1 inch == 2.54 cm  
        this.selectedColumn = selectedColumn;
        this.top_Margin = topMargin;
    }
    
    public void run(){
      start.setEnabled(false);
    
 try{
      ResizeImage resizeImg=new ResizeImage();

        
      document = new Document();
      PdfWriter.getInstance(document, new FileOutputStream(dest));      
      float pageHeight= 11.69f * dpi;
      float pageWidth= 8.27f * dpi;
      int n=selectedFiles.size();  // no ot images in array
      Rectangle one = new Rectangle(pageWidth,pageHeight);  // one page size creating 
      document.setPageSize(one);
      document.setMargins(0,0,top_Margin*dpcm,7);
      System.out.println("MarginTop : "+(10/dpcm)+"  "+(10/dpi) +"  Dpcm:"+dpcm+" dpi"+dpi);
      document.open();

      
      float cellheight= imgHeight * dpcm + 5;
      
      PdfPTable table = new PdfPTable(selectedColumn);
      if(selectedColumn == 2)
      table.setWidthPercentage(98);
      else
       table.setWidthPercentage(98);
        
      
      for(int i=1;i<=n;i++)                      // print only 10 images in one page
    {
        
              Image img=Image.getInstance(selectedFiles.get(i-1));
              PdfPCell cell=new PdfPCell();    
              cell.setBorderWidth(0);
              cell.setFixedHeight(cellheight);
             
              ImageEvent imgEvent = new ImageEvent(img,imgWidth,imgHeight); 
              cell.setCellEvent(imgEvent);
              table.addCell(cell);
            
    }
      if(n %2 == 1) // no of cell is odd so add another cell otherwise this odd cell will not print
       {
            PdfPCell cell=new PdfPCell();    
            cell.setBorderWidth(0);
            cell.setFixedHeight(cellheight);
            table.addCell(cell);
           
       }
    document.add(table);                 
    document.close();
    
    }catch(Exception ex){
    System.out.println(ex);
    }
      finally{ 
       start.setEnabled(true);
      // document.close();
       }
   
    }
}
