/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imageona4;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPCellEvent;
import com.itextpdf.text.pdf.PdfPTable;

/**
 *
 * @author VIVEK
 */

class ImageEvent implements PdfPCellEvent {
    protected Image img;
    float width,height;
    float dpcm;
    public ImageEvent(Image img,float width,float height) {
        this.img = img;
       this.width =width;
       this.height = height;
       float dpi=java.awt.Toolkit.getDefaultToolkit().getScreenResolution();  
        this.dpcm = dpi / 2.54f; // 1 inch == 2.54 cm
        

    }
    
    @Override
    public void cellLayout(PdfPCell cell, Rectangle position, PdfContentByte[] canvases) {
        
    
    //img.scaleAbsolute(position.getWidth()-5, position.getHeight()-5); // 5 is subtracted for default spacing between cells
    
    float imgSizeX=width*dpcm;
    float imgSizeY=position.getHeight()-5f;
    float cellSizeX = position.getWidth();
    float cellSizeY = position.getHeight();
    
    float x= (cellSizeX - imgSizeX )/2;
    float y= (cellSizeY - imgSizeY)/2;
    
    img.scaleAbsolute(width*dpcm,position.getHeight()-5); // only width change here , height change from cell height
    
    //System.out.println(" width : "+(position.getWidth()-5)/dpcm+" Height :"+(position.getHeight()-5)/dpcm);
   
   // img.setAbsolutePosition(position.getLeft(), position.getBottom());
      img.setAbsolutePosition(x+position.getLeft(),y+position.getBottom());
    
   PdfContentByte canvas = canvases[PdfPTable.BACKGROUNDCANVAS];
    try {
        canvas.addImage(img);
    } catch (DocumentException ex) {
        // do nothing
    }
}


}
