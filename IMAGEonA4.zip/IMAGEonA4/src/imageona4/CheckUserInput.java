/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imageona4;

import java.text.DecimalFormat;

/**
 *
 * @author VIVEK
 */
public class CheckUserInput {
    
   public float isHeightOK(float height){
       float maxHeight = 22f;
      DecimalFormat df = new DecimalFormat();
      df.setMaximumFractionDigits(2);
      height = Float.parseFloat(df.format(height)); 
      
      if(height>maxHeight)
      return maxHeight;
      
      if(height<=maxHeight && height>=2f)
      return height;
      else
      return 5.5f;
   }
   public float isWidthOK(float width,int selectedColumn){
       float maxWidth;
       if(selectedColumn == 2)
           maxWidth = 10.1f;
       else
           maxWidth = 15f;
          
      DecimalFormat df = new DecimalFormat();
      df.setMaximumFractionDigits(2);
      width = Float.parseFloat(df.format(width)); 
       if(width<=maxWidth && width>= 2f)
        return width;
    else
        return maxWidth;
       
   }
}
